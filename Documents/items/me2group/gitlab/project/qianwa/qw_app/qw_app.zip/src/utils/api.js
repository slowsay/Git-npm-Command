//数据接口中心
import request from './axios'
   export const baseUrl = '';	//线上地址
//   export const baseUrl = '';   //本地地址

export default {
//接口模板:
//  login(param,data){ //短信登录
//      return request.post(url,param,data)
//  },
//  index: {
//		sleaddressByUserId(param,data){//查询用户的所有地址
//			return request.post(url,param,data)
//		},
//  },

}